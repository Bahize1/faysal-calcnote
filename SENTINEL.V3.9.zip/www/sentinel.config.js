/* Faysal Sentinel AI — configuration publique de télémétrie */
window.FCN_SENTINEL = {
  enabled: true,
  endpoint: "https://lnejzgasypajeqsnyjgh.supabase.co/functions/v1/sentinel-ingest",
  appVersion: "3.9"
};
