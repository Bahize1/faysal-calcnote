/* Faysal Sentinel AI — télémétrie technique minimale.
   Aucun nom, téléphone, montant, poids, détail d'opération ou position GPS n'est transmis. */
(() => {
  "use strict";
  const cfg = window.FCN_SENTINEL || {};
  if (!cfg.enabled || !cfg.endpoint) return;
  try { if (localStorage.getItem("fcn_nolog") === "1") return; } catch (_) {}

  const uuid = () => {
    try { return crypto.randomUUID(); } catch (_) {
      return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, c => {
        const r = Math.random() * 16 | 0;
        return (c === "x" ? r : (r & 3 | 8)).toString(16);
      });
    }
  };
  const getOrCreate = (key) => {
    try {
      let v = localStorage.getItem(key);
      if (!v) { v = uuid(); localStorage.setItem(key, v); }
      return v;
    } catch (_) { return uuid(); }
  };
  const installId = getOrCreate("fcn_sentinel_install");
  const sessionId = uuid();
  const platform = (window.Capacitor && window.Capacitor.isNativePlatform &&
    window.Capacitor.isNativePlatform()) ? "android" : "web";

  async function hash(value) {
    const s = String(value || "unknown").slice(0, 500);
    try {
      const bytes = new TextEncoder().encode(s);
      const digest = await crypto.subtle.digest("SHA-256", bytes);
      return Array.from(new Uint8Array(digest)).map(b => b.toString(16).padStart(2, "0")).join("").slice(0, 32);
    } catch (_) { return "unhashed"; }
  }

  async function send(eventType, raw) {
    try {
      const fingerprint = await hash(raw || eventType);
      const payload = {
        event_type: eventType,
        fingerprint,
        app_version: String(cfg.appVersion || "unknown").slice(0, 20),
        platform,
        install_id: installId,
        session_id: sessionId,
        occurred_at: new Date().toISOString()
      };
      fetch(cfg.endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        keepalive: true,
        mode: "cors"
      }).catch(() => {});
    } catch (_) {}
  }

  window.addEventListener("error", e => {
    const file = (e.filename || "").split("/").pop().slice(0, 80);
    send("js_error", (e.message || "error") + "|" + file);
  });
  window.addEventListener("unhandledrejection", e => {
    const reason = e.reason;
    send("unhandled_rejection", reason && (reason.name || typeof reason) || "promise_rejection");
  });
  window.addEventListener("online", () => send("network_online", "online"));
  window.addEventListener("offline", () => send("network_offline", "offline"));
  send("app_started", platform);
})();
