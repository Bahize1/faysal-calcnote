/* Configuration publique de CalcNote Faysal.
   La cle 'publishable' est PUBLIQUE par nature : la protection vient des comptes et des regles de la base.
   Ne mettez JAMAIS ici la cle service_role ni la cle secrete FedaPay. */
window.FCN_WEB={
  url:"https://ltrxlnbgtkpxklmfeace.supabase.co",
  anon:"sb_publishable_fIkl1wPHtt60CGfGg0jjuA_A9-URcGU",
  site:"https://bahize1.github.io/suivi/",
  billing:true,
  pay:true
};
