// Copie les polices dans www/fonts pour que l'appli fonctionne 100 % hors ligne.
const fs=require('fs'),path=require('path');
const specs=[
 ['manrope','Manrope',[400,500,600,700,800]],
 ['big-shoulders-display','Big Shoulders Display',[700,800]],
 ['instrument-sans','Instrument Sans',[400,500,600,700]],
 ['jetbrains-mono','JetBrains Mono',[400,500,700]],
 ['nunito','Nunito',[400,600,700,800]],
 ['poppins','Poppins',[400,500,600,700]],
 ['merriweather','Merriweather',[400,700]],
 ['patrick-hand','Patrick Hand',[400]]];
fs.mkdirSync('www/fonts',{recursive:true});
let css='';
for(const [pkg,fam,ws] of specs){
 for(const w of ws){
  const f=`${pkg}-latin-${w}-normal.woff2`;
  const src=path.join('node_modules/@fontsource',pkg,'files',f);
  if(!fs.existsSync(src)){console.warn('absent',f);continue;}
  fs.copyFileSync(src,'www/fonts/'+f);
  css+=`@font-face{font-family:'${fam}';font-weight:${w};font-style:normal;font-display:swap;src:url(fonts/${f}) format('woff2')}\n`;
 }}
fs.writeFileSync('www/fonts.css',css);
console.log('polices OK');

// Module optionnel : reconnaissance vocale. S'il n'existe pas dans la bonne version, la compilation continue sans lui.
try{
  require('child_process').execSync('npm install --no-audit --no-fund @capacitor-community/speech-recognition@^6',{stdio:'inherit'});
  console.log('reconnaissance vocale installee');
}catch(e){console.warn('reconnaissance vocale non installee : la saisie vocale sera indisponible dans l\'appli Android');}
