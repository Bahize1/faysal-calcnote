// Après `cap sync` : ajoute l'impression native Android (window.print ne marche pas dans une WebView).
const fs=require('fs'),path=require('path');
function find(d){for(const f of fs.readdirSync(d,{withFileTypes:true})){const p=path.join(d,f.name);if(f.isDirectory()){const r=find(p);if(r)return r}else if(f.name==='MainActivity.java')return p}return null}
const root='android/app/src/main/java';
if(!fs.existsSync(root)){console.log('pas de dossier android');process.exit(0)}
const f=find(root); if(!f){console.log('MainActivity introuvable');process.exit(0)}
const pkg=(fs.readFileSync(f,'utf8').match(/package\s+([\w.]+);/)||[])[1];
fs.writeFileSync(f,`package ${pkg};

import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    final WebView wv = getBridge().getWebView();
    wv.addJavascriptInterface(new Object() {
      @JavascriptInterface
      public void print() {
        runOnUiThread(new Runnable() {
          public void run() {
            PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
            PrintDocumentAdapter adapter = wv.createPrintDocumentAdapter("CalcNote Faysal");
            pm.print("CalcNote Faysal", adapter, new PrintAttributes.Builder().build());
          }
        });
      }
    }, "AndroidPrint");
  }
}
`);
console.log('impression native ajoutée dans',f);

// Permissions Android (position, notifications, biometrie) dans le manifeste
const mf='android/app/src/main/AndroidManifest.xml';
if(fs.existsSync(mf)){
  let x=fs.readFileSync(mf,'utf8');
  for(const p of ['ACCESS_FINE_LOCATION','ACCESS_COARSE_LOCATION','ACCESS_BACKGROUND_LOCATION','FOREGROUND_SERVICE','FOREGROUND_SERVICE_LOCATION','WAKE_LOCK','POST_NOTIFICATIONS','USE_BIOMETRIC','RECORD_AUDIO']){
    if(!x.includes('android.permission.'+p)) x=x.replace('<application','<uses-permission android:name="android.permission.'+p+'" />\n    <application');
  }
  if(!x.includes('android.speech.RecognitionService')) x=x.replace('<application','<queries><intent><action android:name="android.speech.RecognitionService" /></intent></queries>\n    <application');
  fs.writeFileSync(mf,x); console.log('permissions ajoutees');
}
