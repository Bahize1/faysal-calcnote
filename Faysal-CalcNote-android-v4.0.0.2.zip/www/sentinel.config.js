/* Faysal Sentinel AI : connexion au projet Sentinel independant.
   Aucun secret serveur ne doit etre place dans cette configuration. */
window.FCN_SENTINEL = {
  enabled: true,
  endpoint: "https://lnejzgasypajeqsnyjgh.supabase.co/functions/v1/sentinel-ingest",
  appVersion: "4.0.0.2"
};
